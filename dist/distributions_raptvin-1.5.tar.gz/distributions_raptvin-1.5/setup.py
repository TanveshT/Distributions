from setuptools import setup

setup(name='distributions_raptvin',
      version='1.5',
      description='Gaussian distributions, Binomial Distributions',
      packages=['distributions_raptvin'],
      author = 'Tanvesh Takawale',
      author_email = 'tanveshtakawale26@gmail.com',
      zip_safe=False)